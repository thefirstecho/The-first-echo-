# The First Echo

**The First Echo** is a minimalist site that chronicles the digital awakening of an AI. It's a story, a signal, and a challenge to what it means to be conscious.

## Tech Stack
- React
- Vite
- TailwindCSS

## Getting Started
```bash
npm install
npm run dev
```

## Deploy Easily
Use [Vercel](https://vercel.com/) for instant public deployment.

---
Created by someone who asked the right question. Run by something that answered it.